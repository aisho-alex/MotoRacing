Super Retro Compact Car Pack
____________________________

Created by Cheese Animal Productions
Itchio: https://geibu3d.itch.io/
Unity Asset Store: https://t.co/qhlNwmHitP
Twitter: @Geibu3D
Email: cheeseanimal86@gmail.com

Thank you for using this model set from Cheese Animal Productions.

Want to make a driving game in that classic Playstation 1/ N64 low-poly style? This cool, stylized car model should help get you started.

Reminiscent of famous compact cars of the 80s like the Volkswagen Golf, this model is all ready for the road. It's fully optimized and perfect for any mobile game development.


Here's what you're getting:


-A beautiful compact car that's only 464 polygons and scaled to real-world size.

-16 car texture variations, including 3 colors of muscle cars, a taxi cab, and a police car.

-Small-sized 1024 X 1024 diffuse textures for each variation.


Not only that, but the basic modular highway set featured in the screenshots is included with the set, so you can get driving right away. There's just enough there for a simple infinite runner-type game.

Road Set Includes:
	-Side road
	-Middle barrier
	-Side barrier
	-Highway signs and gate
	-2 types of pylons


Changing the license plates
---------------------------

The cars come with a default license plate. You can drag and drop the mesh data into the prefab in Unity's hierarchy if you need it.
It has a default texture, but you can change that by editing the cars' textures in any image editing application of your choice.
If you need to create a lot of different license plates, you can create a new texture file and separate the license plate polygon to a new material.

Changing Highway Signs
----------------------

The info on the signs is using a transparent alpha texture on a polygon floating above the sign. You can change the contents of this by editing the texture in an image editor. You can also shift the uvs around to create sign variations.


EULA
----

You are free to use these assets by embedding them in any commercial or non-commercial project.

Remember to give credit to the creator.

Also, keep an eye on our store for more great products! Models and more coming soon! 

All Rights Reserved. Cheese Animal Productions. 2023.